package com.stackroute.newz.util.exception;

public class NewsSourceNotCreatedException extends Exception {

	private static final long serialVersionUID = 1L;

	public NewsSourceNotCreatedException(String message) {
		super(message);
	}
}
