package com.stackroute.newz.model;

import java.util.List;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.annotation.Id;


/*
 * Please note that this class is annotated with @Document annotation
 * @Document identifies a domain object to be persisted to MongoDB.
 * 
 */

@EntityScan
public class UserNews {

	/*
	 * This class should have two fields (userId, newslist).Out of these two fields,
	 * the field userId should be annotated with @Id. This class should also contain
	 * the getters and setters for the fields.
	 */

	@Id
    private long userId;
    private List<News> newslist;
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public List<News> getNewslist() {
		return newslist;
	}
	public void setNewslist(List<News> newslist) {
		this.newslist = newslist;
	}
    
    
	
	/*
	 * public String getUserId() { return null; }
	 * 
	 * public void setUserId(String userId) {
	 * 
	 * }
	 * 
	 * public List<News> getNewslist() { return null; }
	 * 
	 * public void setNewslist(List<News> newslist) {
	 * 
	 * }
	 */

}
